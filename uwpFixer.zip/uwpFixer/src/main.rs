#![windows_subsystem = "windows"]

use std::ptr;
use std::ffi::CString;
use std::ffi::CStr;
use std::mem;
use std::thread;
use std::time::Duration;
use winapi::um::winuser::*;
use winapi::um::shellapi::*;
use winapi::shared::minwindef::*;
use winapi::shared::windef::*;
use winapi::shared::ntdef::*;
use winapi::um::libloaderapi::*;
use winapi::um::wingdi::*;
use winapi::ctypes::c_int;
use winapi::shared::guiddef::GUID;
use std::convert::TryInto;
use winapi::um::winuser::MessageBoxA;
use winapi::um::winuser::MB_ICONINFORMATION;
use winapi::um::tlhelp32::*;
use winapi::um::processthreadsapi::*;
use winapi::um::handleapi::*;
use winapi::um::processthreadsapi::OpenProcess;
use winapi::um::winnt::PROCESS_TERMINATE;
use libc::wchar_t;

extern crate libc;

extern "C" {
    pub fn _wcsicmp(_String1: *const wchar_t, _String2: *const wchar_t) -> c_int;
}

const WM_COMMAND: UINT = 0x0111;
const WM_TRAYICON: UINT = WM_USER + 1;
const ID_TRAY_EXIT_CONTEXT_MENU_ITEM: UINT = 2;
const ID_TRAY_CREDITS_CONTEXT_MENU_ITEM: UINT = 3;
static mut SHOULD_TERMINATE: bool = false;

struct NOTIFYICONDATAWrapper {
    cbSize: DWORD,
    hWnd: HWND,
    uID: UINT,
    uFlags: UINT,
    uCallbackMessage: UINT,
    hIcon: HICON,
    szTip: [CHAR; 128],
}

impl Default for NOTIFYICONDATAWrapper {
    fn default() -> Self {
        Self {
            cbSize: std::mem::size_of::<NOTIFYICONDATAWrapper>() as DWORD,
            hWnd: ptr::null_mut(),
            uID: 0,
            uFlags: 0,
            uCallbackMessage: 0,
            hIcon: ptr::null_mut(),
            szTip: [0; 128],
        }
    }
}

static mut MOUSE_SAVED: bool = false;
static mut SAVED_POINT: POINT = POINT { x: 0, y: 0 };
static mut ROBLOX_WINDOW: HWND = ptr::null_mut();

fn is_roblox_active() -> bool {
    unsafe {
        let foreground = GetForegroundWindow();
        if !foreground.is_null() {
            let mut window_title = [0 as CHAR; 256];
            GetWindowTextA(foreground, window_title.as_mut_ptr(), window_title.len() as c_int);
            let window_title_str = {
                let cstr = CStr::from_ptr(window_title.as_ptr());
                cstr.to_string_lossy().to_string()
            };
            
            if window_title_str == "Roblox" {
                ROBLOX_WINDOW = foreground;
                return true;
            }
        }
        ROBLOX_WINDOW = ptr::null_mut();
        false
    }
}

fn get_scaled_title_bar_height() -> c_int {
    const REFERENCE_HEIGHT: c_int = 1080;
    const REFERENCE_TITLE_BAR_HEIGHT: c_int = 40;

    unsafe {
        let screen = GetDC(ptr::null_mut());
        let current_height = GetDeviceCaps(screen, VERTRES);
        ReleaseDC(ptr::null_mut(), screen);

        let scale_factor = f32::from(current_height as f32) / f32::from(REFERENCE_HEIGHT as f32);

        ((REFERENCE_TITLE_BAR_HEIGHT as f32) * scale_factor) as c_int
    }
}

fn constrain_cursor_to_roblox() {
    unsafe {
        if ROBLOX_WINDOW.is_null() {
            return;
        }

        let mut client_rect = RECT {
            left: 0,
            top: 0,
            right: 0,
            bottom: 0,
        };

        if GetClientRect(ROBLOX_WINDOW, &mut client_rect) != 0 {
            let mut top_left = POINT { x: client_rect.left, y: client_rect.top };
            let mut bottom_right = POINT { x: client_rect.right, y: client_rect.bottom };

            ClientToScreen(ROBLOX_WINDOW, &mut top_left);
            ClientToScreen(ROBLOX_WINDOW, &mut bottom_right);

            let title_bar_height = get_scaled_title_bar_height();
            top_left.y += title_bar_height;

            let screen_rect = RECT {
                left: top_left.x,
                top: top_left.y,
                right: bottom_right.x,
                bottom: bottom_right.y,
            };
            ClipCursor(&screen_rect);
        }
    }
}

fn free_cursor() {
    unsafe {
        ClipCursor(ptr::null_mut());
    }
}

unsafe extern "system" fn low_level_mouse_proc(n_code: c_int, w_param: WPARAM, l_param: LPARAM) -> LRESULT {
    println!("Mouse Hook triggered. Event: {}", w_param);
    if n_code == HC_ACTION {
        if is_roblox_active() {
            match w_param as u32 {
                WM_RBUTTONDOWN => {
                    MOUSE_SAVED = true;
                    GetCursorPos(&mut SAVED_POINT);
                    println!("Mouse position saved: ({}, {})", SAVED_POINT.x, SAVED_POINT.y);
                }
                WM_RBUTTONUP => {
                    if MOUSE_SAVED {
                        SetCursorPos(SAVED_POINT.x, SAVED_POINT.y);
                        println!("Mouse position reset to saved position.");
                        MOUSE_SAVED = false;
                    }
                }
                WM_MOUSEMOVE => constrain_cursor_to_roblox(),
                _ => (),
            }
        } else {
            free_cursor();
        }
    }
    CallNextHookEx(ptr::null_mut(), n_code, w_param, l_param)
}

unsafe extern "system" fn window_proc(hwnd: HWND, u_msg: UINT, w_param: WPARAM, l_param: LPARAM) -> LRESULT {
    match u_msg {
        WM_TRAYICON => {
            if l_param == WM_RBUTTONUP as LPARAM {
                let mut cur_point = POINT { x: 0, y: 0 };
                GetCursorPos(&mut cur_point);
                SetForegroundWindow(hwnd);

                let h_menu = CreatePopupMenu();
                if h_menu != ptr::null_mut() {
                    InsertMenuA(
                        h_menu,
                        u32::MAX as UINT,
                        MF_BYPOSITION,
                        ID_TRAY_CREDITS_CONTEXT_MENU_ITEM.try_into().unwrap(),
                        "Credits\0".as_ptr() as LPCSTR,
                    );
                    InsertMenuA(
                        h_menu,
                        u32::MAX as UINT,
                        MF_BYPOSITION | MF_SEPARATOR,
                        0,
                        ptr::null_mut(),
                    );
                    InsertMenuA(
                        h_menu,
                        u32::MAX as UINT,
                        MF_BYPOSITION,
                        ID_TRAY_EXIT_CONTEXT_MENU_ITEM.try_into().unwrap(),
                        "Quit\0".as_ptr() as LPCSTR,
                    );
                    
                    TrackPopupMenu(h_menu, TPM_BOTTOMALIGN | TPM_LEFTALIGN, cur_point.x, cur_point.y, 0, hwnd, ptr::null_mut());
                    DestroyMenu(h_menu);
                }
            }
            0 // Return an integer as LRESULT
        }
        WM_COMMAND => {
            let menu_item_id = u32::from(LOWORD(w_param as DWORD));
            match menu_item_id {
                ID_TRAY_EXIT_CONTEXT_MENU_ITEM => {
                    PostQuitMessage(0);
                }
                ID_TRAY_CREDITS_CONTEXT_MENU_ITEM => {
                    MessageBoxA(
                        hwnd,
                        b"Created by: dtblinux\nOriginal Cpp version by Osiris\0".as_ptr() as LPCSTR,
                        b"Credits\0".as_ptr() as LPCSTR,
                        MB_ICONINFORMATION,
                    );
                }
                _ => (),
            }
            0 // Return an integer as LRESULT
        }
        WM_DESTROY => {
            unsafe {
                SHOULD_TERMINATE = true;
                PostQuitMessage(0);
            }
            0
        }
        _ => DefWindowProcA(hwnd, u_msg, w_param, l_param),
    }
}

const PROCESSES_TO_TERMINATE: [&str; 2] = ["RuntimeBroker.exe", "Roblox.exe"];

fn terminate_roblox_instances() {
    loop {
        if unsafe { SHOULD_TERMINATE } {
            break;
        } 
        unsafe {
            let h_snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
            if h_snapshot == INVALID_HANDLE_VALUE {
                eprintln!("Error creating process snapshot.");
                return;
            }

            let mut pe32: PROCESSENTRY32W = mem::zeroed();
            pe32.dwSize = mem::size_of::<PROCESSENTRY32W>() as u32;

            if Process32FirstW(h_snapshot, &mut pe32) == 0 {
                eprintln!("Error getting process information.");
                CloseHandle(h_snapshot);
                return;
            }

            loop {
                for &process_name in PROCESSES_TO_TERMINATE.iter() {
                    if _wcsicmp(pe32.szExeFile.as_ptr(), process_name.encode_utf16().collect::<Vec<u16>>().as_ptr()) == 0 {
                        println!("- Detected New Roblox Instance:");

                        let h_process = OpenProcess(PROCESS_TERMINATE, 0, pe32.th32ProcessID);
                        if h_process != NULL {
                            if TerminateProcess(h_process, 0) != 0 {
                                println!("Fixed Roblox Instance");
                            } else {
                           
                            }

                            CloseHandle(h_process);
                        } else {
                           
                        }
                    }
                }

                if Process32NextW(h_snapshot, &mut pe32) == 0 {
                    break;
                }
            }

            CloseHandle(h_snapshot);
        }

        thread::sleep(Duration::from_secs(5));
    }
}

fn main() {
    unsafe {
        let class_name = CString::new("Sample Window Class").unwrap();

        let wc = WNDCLASSA {
            style: 0,
            lpfnWndProc: Some(window_proc),
            cbClsExtra: 0,
            cbWndExtra: 0,
            hInstance: GetModuleHandleA(ptr::null_mut()),
            hIcon: LoadIconA(ptr::null_mut(), IDI_APPLICATION as LPCSTR),
            hCursor: LoadCursorA(ptr::null_mut(), IDC_ARROW as LPCSTR),
            hbrBackground: COLOR_BACKGROUND as HBRUSH,
            lpszMenuName: ptr::null(),
            lpszClassName: class_name.as_ptr(),
        };

        RegisterClassA(&wc);

        let hwnd = CreateWindowExA(
            0,
            class_name.as_ptr(),
            b"Sample Window Name\0".as_ptr() as LPCSTR,
            WS_OVERLAPPEDWINDOW,
            CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
            ptr::null_mut(),
            ptr::null_mut(),
            GetModuleHandleA(ptr::null_mut()),
            ptr::null_mut(),
        );

        if hwnd.is_null() {
            return;
        }

        let mut nid: NOTIFYICONDATAA = NOTIFYICONDATAA {
            cbSize: mem::size_of::<NOTIFYICONDATAA>() as DWORD,
            hWnd: hwnd,
            uID: 1,
            uFlags: NIF_ICON | NIF_MESSAGE | NIF_TIP,
            uCallbackMessage: WM_TRAYICON,
            hIcon: LoadIconA(ptr::null_mut(), IDI_APPLICATION as LPCSTR),
            szTip: [0; 128], // Initialize szTip array with zeros
            dwState: 0,
            dwStateMask: 0,
            szInfo: [0; 256], // Initialize szInfo array with zeros
            dwInfoFlags: 0,
            u: { std::mem::zeroed() }, // Initialize the union
            szInfoTitle: [0; 64], // Initialize szInfoTitle array with zeros
            guidItem: GUID {
                Data1: 0,
                Data2: 0,
                Data3: 0,
                Data4: [0; 8],
            },
            hBalloonIcon: ptr::null_mut(),
        };

        let tip_text = "UWPFixer V.2.0.0 By dtblinux\0";
        let tip_length = tip_text.len();
        ptr::copy_nonoverlapping(tip_text.as_ptr() as *const i8, nid.szTip.as_mut_ptr(), tip_length);
        
        Shell_NotifyIconA(NIM_ADD, &mut nid as *mut _);

        let mouse_hook = SetWindowsHookExA(WH_MOUSE_LL, Some(low_level_mouse_proc), ptr::null_mut(), 0);
        if mouse_hook.is_null() {
            return;
        }

        let terminate_thread = thread::spawn(terminate_roblox_instances);

        let mut msg: MSG = mem::zeroed();

        while GetMessageA(&mut msg, ptr::null_mut(), 0, 0) > 0 {
            TranslateMessage(&msg);
            DispatchMessageA(&msg);

            unsafe {
                if SHOULD_TERMINATE {
                    break;
                }
            }
        }

        Shell_NotifyIconA(NIM_DELETE, &mut nid as *mut _);
        UnhookWindowsHookEx(mouse_hook);

        terminate_thread.join().unwrap();
    }
}